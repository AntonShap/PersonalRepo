$(function() {
  var el= document.getElementById("myspace");

  if (el && el.getContext) {
    var context = el.getContext("2d");
    // Create gradient
    var grd = context.createRadialGradient(150,100,5,150,100,60);
    grd.addColorStop(0,"#1808ff");
    grd.addColorStop(1,"#fff");

    context.beginPath();
    context.fillStyle = grd;
    context.strokeStyle = "#000";
    context.lineWidth = 2;
    context.arc(150, 100, 60, 0, Math.PI*2, false);
    context.closePath();
    context.stroke(); 
    context.fill();
    }    
  })
