
$(function() {
var el= document.getElementById("flag");

if (el && el.getContext) {
  var context = el.getContext('2d');
    if (context) {
      context.fillStyle  = "#ffffff";
      context.strokeStyle = "#cccccc";
      context.lineWidth  = 1;
      context.shadowOffsetX = 5;
      context.shadowOffsetY = 5;
      context.shadowBlur  = 4;
      context.shadowColor  = 'rgba(0, 0, 0, 0.4)';
      context.strokeRect(10, 10, 300, 200);
      context.fillRect(10, 10, 300, 200);
      context.shadowColor='rgba(0,0,0,0)';
      context.beginPath();
      context.fillStyle = "#d60818";
      context.arc(160, 107, 60, 0, Math.PI*2, false);
      context.closePath();
      context.fill();
    }
  }
})
