function SomeController($scope) {
  $scope.greeting = { text: 'How cool is this!' };
}