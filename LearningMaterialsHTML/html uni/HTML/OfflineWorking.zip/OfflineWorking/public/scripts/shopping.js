$(function() {
  var userName = prompt("Please enter your name");
  sessionStorage.setItem('userName', userName);
  
  $('#submitItem').click(function(event) {
    var item = $('#item').val();
    $('#item').val("");
    localStorage.setItem('newItem', item);
  })
})

