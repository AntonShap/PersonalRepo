// File: heavyLiftingServer.js
// Responses slowed down to simulate high latency

// fetch the node-static and http modules
var static = require('node-static');
var http = require('http');
var exec = require('child_process').exec;

var webroot = './public';
var port = 8080;


var file = new static.Server(webroot);

var app = http.createServer(function(request, response) {
  exec("sleep 1s;", function(error, stdout, stderror) {
    file.serve(request, response, function(error, result) {
      if (error) {
        console.error('Error serving ' + request.url + ' - ' + error.message);
        response.writeHead(error.status, error.headers);
        response.end();
      } else {
        console.log(request.url + ' - ' + result.message);
      }
    });
  });
}).listen(port);

console.log('node-static running at http://localhost:%d', port)