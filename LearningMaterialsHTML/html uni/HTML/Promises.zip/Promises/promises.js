var Promise = require('es6-promise').Promise;
var exec = require('child_process').exec;

var doStuff = function() {

  var promise = new Promise(function(resolve, reject) {

    // Do stuff that may take some time - like sleeping :)
    exec("sleep 5s;", function(error, stdout, stderror) {
      var test = 10 * Math.random();

      if ( test < 5 ) {
        resolve("It worked");
      }
      else {
        reject(Error("It broke"));
      }

    });
  })

  promise.then(function(result) {
    console.log(result);
  }, function(error) {
    console.log(error);
  });
}
