// From Jake Archibald
var Promise = require('es6-promise').Promise;


var promise = new Promise(function(resolve, reject) {

  // Do stuff that may take some time
    if ( fulfillment_condition ) {
      resolve("It worked");
    }
    else {
      reject(Error("It broke"));
    }
  })

promise.then(function(result) {
  console.log(result);
}, 
function(error) {
  console.log(error);
}
);
