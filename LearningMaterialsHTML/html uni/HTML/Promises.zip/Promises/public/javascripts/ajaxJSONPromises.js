// File ajaxPromises.js

$(function() {
  $('#heavydata').click(function() {
    getJSON("http://localhost:8080/stuff.json").then(function(response) {
      $("<p>" + response.text + "</p>").appendTo("#heavydata");
      console.log("Success!", response.text);
    }, function(error) {
      $("<p>Data unavailable</p>").appendTo("#heavydata");
      console.error("Failed!", error);
    });
  });

  $('#noname').click(function() {
    getJSON("http://localhost:8080/absentfriend.json").then(function(response) {
      $("<p>" + response.text + "</p>").appendTo("#noname");
      console.log("Success!", response);
    }, function(error) {
      $("<p>Data unavailable</p>").appendTo("#noname");
      console.error("Failed!", error);
    });
  });
});

// The following after Jake Archibald:
// http://www.html5rocks.com/en/tutorials/es6/promises/

function get(url) {
  // Return a new promise.
  return new Promise(function(resolve, reject) {
    // Do the usual XHR stuff
    var req = new XMLHttpRequest();
    req.open('GET', url);

    req.onload = function() {
      // This is called even on 404 etc
      // so check the status
      if (req.status == 200) {
        // Resolve the promise with the response text
        resolve(req.response);
      }
      else {
        // Otherwise reject with the status text
        // which will hopefully be a meaningful error
        reject(Error(req.statusText));
      }
    };

    // Handle network errors
    req.onerror = function() {
      reject(Error("Network Error"));
    };

    // Make the request
    req.send();
  });
}

function getJSON(url) {
  return get(url).then(JSON.parse);
}
