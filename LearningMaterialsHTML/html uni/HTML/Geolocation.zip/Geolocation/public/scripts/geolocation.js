$(function() {
  if (navigator.geolocation) {
    // geolocation is supported
    navigator.geolocation.getCurrentPosition(success_handler, failure_handler);
  } else {
    console.log("Geolocation is not supported");
  }
})

function success_handler(position) {
  var latitude = position.coords.latitude;
  var longitude = position.coords.longitude;
  var url = "http://maps.google.com/maps?q=" + latitude + "," + longitude;
  $("<a href=" + url 
    + ">Click here to see your location</href>").appendTo("#locationInfo");
}

function failure_handler(error) {
  switch(error.code) {
    case error.PERMISSION_DENIED:
      msg = "User refused permission";
      break;
    case error.POSITION_UNAVAILABLE:
      msg = "Cannot obtain current position";
      break;
    case error.TIMEOUT:
      msg = "Timed out";
      break;
    default:
      msg = "Don't know what's happening here!";
      break;
  };
  $("<p>Location information is not available because: " 
    + msg + "</p>").appendTo("#locationInfo");
}
